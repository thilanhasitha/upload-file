package member;

public class member {
	private String FirstName;
	private String LastName;
	private String email;
	private int age;
	private String address;
	private String username;
	private String password;
	
	public member()
	{}
	public member(String firstName, String lastName, String email, int age, String address, String username,
			String password) {
		super();
		this.FirstName = firstName;
		this.LastName = lastName;
		this.email = email;
		this.age = age;
		this.address = address;
		this.username = username;
		this.password = password;
	}
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	}
	
	


