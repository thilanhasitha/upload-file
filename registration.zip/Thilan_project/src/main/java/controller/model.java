package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import member.member;

public class model {
	
	private String dburl = "jdbc:mysql://localhost:3306/thilan";
	private String dbusername = "root";
	private String dbpassword = "root";
	private String driver = "com.mysql.jdbc.Driver";
	
	public void loadDriver(String driver)
	{
		try {
			Class.forName("driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection()
	{
		
		Connection con = null;
		try {
			con = DriverManager.getConnection(dburl,dbusername,dbpassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	public String insert(member m1)
	{
		loadDriver(driver);
		Connection con = getConnection();
		String result = "Data entered successfully";
		
		String sql = "Insert into customer values(?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,m1.getFirstName());
			ps.setString(2,m1.getLastName());
			ps.setString(3,m1.getEmail());
			ps.setInt(4,m1.getAge());
			ps.setString(5,m1.getAddress());
			ps.setString(6,m1.getUsername());
			ps.setString(7,m1.getPassword());
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "Data not ntered";
		}
		return result;
		
	}
	

}
